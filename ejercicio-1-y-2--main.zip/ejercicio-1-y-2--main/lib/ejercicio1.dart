void main() {
  final calculadora = new Calculadora();
  int num1=4;
  int num2=2;
  print('La suma es:: ${calculadora.suma(num1, num2)}');
  print('La resta es: ${calculadora.resta(num1, num2)}');
  print('El producto es: ${calculadora.multiplicacion(num1, num2)}');
}
abstract class Operacion {
  int suma(int a, int b);
  int resta(int a, int b);
  int multiplicacion(int a, int b);
}

class Calculadora implements Operacion {
  int suma(int a, int b) => a + b;
  int resta(int a, int b) => a - b;
  int multiplicacion(int a, int b) => a * b;
}
/*
void resolver(Operacion operacion, int num1, int num2){
  operacion.mostrar(num1, num2);
}

abstract class Operacion{
  int? num1;
  int? num2;
  void mostrar(num1, num2);
}
class Suma implements Operacion{
  int? num1;
  int? num2;
  void mostrar(num1, num2) => print("La suma es: ${num1+num2}");
}
class Resta implements Operacion{
  int? num1;
  int? num2;
  void mostrar(num1, num2) => print("La resta es: ${num1-num2}");
}
class Multiplicacion implements Operacion{
  int? num1;
  int? num2;
  void mostrar(num1, num2) => print("El producto es: ${num1*num2}");
}*/