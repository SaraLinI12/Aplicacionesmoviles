void main() {
// Strings
  final String nombre = 'Tony';
  final apellido = 'Stark';
// nombre = 'Peter';
  print('$nombre $apellido');
  var aa='asdfaddf';
  var valor=0;
  // Números
  int empleados = 10;
  double salario = 1856.25;
  print(empleados);
  print(salario);
  print(aa);
  print(valor);
}