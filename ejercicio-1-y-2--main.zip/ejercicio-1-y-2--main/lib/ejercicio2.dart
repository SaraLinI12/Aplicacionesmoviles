void main() {
  final calculadora = Calculadora();
  int num1 = 4;
  int num2 = 2;
  calculadora.mostrarResultados(num1, num2);
}

class Operacion {
  int suma(int a, int b) => a + b;
  int resta(int a, int b) => a - b;
  int multiplicacion(int a, int b) => a * b;
}

class Calculadora extends Operacion {
  void mostrarResultados(int a, int b) {
    print("La suma es: ${suma(a, b)}");
    print("La resta es: ${resta(a, b)}");
    print("El producto es: ${multiplicacion(a, b)}");
  }
}