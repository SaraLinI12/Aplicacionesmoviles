void main() {
print("Hola mundo");
}